
public class Drawing {
    
    
    public static void main(String[] args) { 
        drawSquare(5);
    }
    
    // a method that takes an int as input and displays a full square of that size
    /*
     * drawSquare(3)
     * +++
     * +++
     * +++
     */ 
    public static void drawSquare(int size) {
        // outer loop for the number of horizontal lines in the square
        for(int i=0; i<size; i++) {
            // display a line made of size '+'s
            //printLine(size);
            for(int j=0; j<size; j++) {
                System.out.print('+');
            }
            System.out.println();
        }
    }
    
    public static void printAltLine(int n) {
        //String s = "+";
        for(int i=0; i<n; i++) {
            if(i%2==0) {
                System.out.print('+');
            } else {
                System.out.print('-');
            }
        }
        System.out.println();
    }
    
    public static void printLine(int n) {
        for(int i=0; i<n; i++) {
            System.out.print('+');
        }
        System.out.println();
    }
}
