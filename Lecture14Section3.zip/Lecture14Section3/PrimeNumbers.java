public class PrimeNumbers {
        
    public static void main(String[] args) { 
        System.out.println(isPrime(9));
    }
    
    // a method that takes an integer as input and returns true if such 
    // number is prime, false otherwise
    /*
     * isPrime(5) --> true
     * isPrime(6) --> false
     * isPrime(-10) --> false
     */ 
    public static boolean isPrime(int n) {
        if(n<=1) {
            System.out.println("The input should be greater than 1");
            return false;
        }
        // IDEA: follow the trial division idea
        // iterate through all the possible divisors
        for(int div=2; div <= n-1; div++) {
            // check whether n is evenly disivible by div
            if(n%div == 0) {
                return false;
            } 
        }
        return true;
    }
    
}
