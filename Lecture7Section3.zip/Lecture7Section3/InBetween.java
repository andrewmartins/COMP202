/**
 * A program that takes 3 ints as input x, y, z
 * diplays true if y is in between x and z, false otherwise
 */
public class InBetween {
    
    public static void main(String[] args) { 
        // 1) Retrieve 3 ints as input
        int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[1]);
        int z = Integer.parseInt(args[2]);
        // 2) check whether y is in between x and z
        boolean inBetween = (x<=y && y<=z) || (x>=y && y>=z);
        // 3) Display the info
        System.out.print(y + " is a number in between " + x);
        System.out.println(" and " + z + ": " + inBetween);
    }
    
}
