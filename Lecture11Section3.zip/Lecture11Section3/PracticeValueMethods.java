public class PracticeValueMethods {
        
    public static void main(String[] args) { 
        // test cube
        //System.out.println(cube(2.0));
        //System.out.println(cube(-3.0));
        
        // test volumeSphere
        System.out.println(volumeSphere(5.5));
    }
    
    // a method that computes the volume of sphere given its radius (as input)
    /*
     * volumeSphere(3.0) --> 113.097335...
     */
    public static double volumeSphere(double radius) {
        // (4/3)*pi*radius^3
        double volume = 4.0/3*Math.PI*cube(radius);
        return volume;
    }
    
    // a method that computes the cube of a number received as input to the method
    /*
     * cube(2.0) --> 8.0
     * cube(-3.0) --> -27.0
     */
    public static double cube(double x) {
        return Math.pow(x,3.0);
    }
}
