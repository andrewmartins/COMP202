public class SimpleCalc {
        
    public static void main(String[] args) { 
        // 1) retrieve 3 input (int String int)
        int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[2]);
        String op = args[1];
        
        // check that the retrieve worked correctly
        // System.out.println(x + " " + op + " " + y);
        
        // 2) check whether or not the operation is supported
        
        if(op.equals("+")) {
            System.out.println(x+y);
        } else if (op.equals("-")) {
            System.out.println(x-y);
        } else if (op.equals("*")) {
            System.out.println(x*y);
        } else {
            System.out.println("Operation not supported!");
        }
            
        
        // 3) Display the result
    }
    
}
