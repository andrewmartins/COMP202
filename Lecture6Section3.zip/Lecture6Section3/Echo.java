// a program that repeats the input that it is provided with
public class Echo {
    public static void main(String[] args) {
        int sum =Integer.parseInt(args[0])+ Integer.parseInt(args[1]);
        System.out.println("Your word is " + sum);
    }
}