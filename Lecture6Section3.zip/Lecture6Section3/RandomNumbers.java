public class RandomNumbers {
    
    public static void main(String[] args) { 
        double x = Math.random()*10;
        System.out.println("Random double between 0 and 10: " + x);
        
        int y = (int) (Math.random()*10);
        System.out.println("Random int between 0 and 10: " + y);
        
        int max = Integer.parseInt(args[0]);
        int z = (int) (Math.random()*max);
        System.out.println("Random int between 0 and " + max + ": " + z);
    }
    
    
}
