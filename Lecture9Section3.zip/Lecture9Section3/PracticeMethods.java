public class PracticeMethods {

    public static void main(String[] args) {
        // testing printLine
        //printLine();
        
        // test printBox
        //printBox();
        //System.out.println();
        //printBox();
        
        printLine('*');
    }
    
    // a method that displays a line made of 5 characters, where the char
    // is taken as input
    public static void printLine(char symbol) {
        System.out.println("" + symbol + symbol + symbol + symbol + symbol);
    }
    
    // a method that display a 4 by 5 box made of '+'s
    public static void printBox() {
        printLine('*');
        printLine('*');
        printLine('*');
        printLine('*');
    }
    /*
    // a method that displays a line made of 5 '+'s
    public static void printLine() {
        System.out.println("+++++");
    }*/
    
    // a method that diplays the cities in which we lived one per line
    public static void myCities() {
        System.out.println("Montreal, Canada");
        System.out.println("PAP, Haiti");
        System.out.println("Toronto, Canada");
        System.out.println("Milano, Italia");
    }
    
    public static void yourCities() {
        System.out.println("Montreal, Canada");
    }
   

}