public class PracticeStrings {
    
    public static void main(String[] args) { 
        System.out.println(isVowel("Apple",0));
    }
    
    // a method that takes a String s and an int i as input
    // the method returns true if the character of s at index i is a vowel
    // false otherwise
    /*
     * isVowel("Apple", 1) --> false
     * isVowel("Apple", 4) --> true
     * isVowel("Apple", 0) --> true
     */
    public static boolean isVowel(String s, int i) {
        // converting the string in lower case
        String t = s.toLowerCase();
        // selecting the character at index i
        char c = t.charAt(i);
        // checking if it's a vowel
        if(c == 'a' || c == 'e' || c=='i' || c=='o' || c=='u' ) {
            return true;
        }
        return false;
    }
}
