public class PracticeWithLoops {    
    
    public static void main(String[] args) { 
        printLine('*', -4);
        printLine('$');
        //printLine('#',5);
        //printLine('%',5);
        System.out.println(reverseString("bananagrams"));
    }
    
    // a method that takes a String as input and returns a new String
    // made of the same characters of the input string but in rever order
    /*
     * reverseString("apple") --> "elppa"
     */ 
    public static String reverseString(String word) {
        String t = ""; 
        // use a loop to iterate from the last char of word to the first one
        for(int index = word.length() -1; index >= 0; index --) {
            // index = 4
            // t = "" + 'e' = "e"
            // index = 3
            // t = "e" + 'l' = "el"
            t = t + word.charAt(index);
        }
        return t;
    }
    
    // overload printLine by adding an int as input
    // the method should display the given char the specified amount of times
    /*
     * printLine('@', 5) --> @@@@@
     * printLine('#', 0) --> 
     * printLine('$',-4) --> "the integer should be positive"
     */ 
    public static void printLine(char symbol, int n) {
        // validate the input
        if(n <0) {
            System.out.println("the integer should be positive");
            return;
        } 
        // use a for loop that iterates n times
        for(int i = 1; i <= n; i++) {
            // print the given char at each iteration
            System.out.print(symbol);
        }
        System.out.println();
        
    }
    
    public static void printLine(char c) {
        System.out.println(""+c+c+c+c+c);
    }
    
}
