/**
 * A program that takes an int as input and display whether or not
 * this input is even
 */
public class IsEven {
    
    public static void main(String[] args) { 
        // 1) Retrieve and int as input
        int n = Integer.parseInt(args[0]);
        // 2) Check whether the input is an even number
        boolean isEven = n%2==0;
        // 3) Display the info
        //System.out.println(n + " is an even number: " + isEven);
        if(isEven) {
            System.out.println(n + " is an even number");
        } else { 
            if(n%3 == 0) {
                System.out.println(n + " is an odd number multiple of 3");
            } else {
                System.out.println(n + " is an odd number and not a multiple of 3");
            }
        }
        
        
    }
    
}
